package com.examen.tendenciasfinalkevin.models;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "periodo")
public class Periodo {
    private String periodo;
    private Integer year;
}
