package com.examen.tendenciasfinalkevin.service;

import com.examen.tendenciasfinalkevin.models.Profesor;


public interface ProfesorService extends GenericService<Profesor, Long> {
}
