package com.examen.tendenciasfinalkevin.repository;

import com.examen.tendenciasfinalkevin.models.Profesor;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProfesorRepository extends MongoRepository<Profesor, Long> {
}
