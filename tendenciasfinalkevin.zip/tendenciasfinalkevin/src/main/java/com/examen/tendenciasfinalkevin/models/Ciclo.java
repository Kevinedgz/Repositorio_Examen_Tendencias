package com.examen.tendenciasfinalkevin.models;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "Ciclo")
public class Ciclo {
    private String nombre;
    private String descripcion;
    private Carrera carrera;
}
