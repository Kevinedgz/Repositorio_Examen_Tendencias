package com.examen.tendenciasfinalkevin.controllers;

import com.examen.tendenciasfinalkevin.models.Profesor;
import com.examen.tendenciasfinalkevin.service.ProfesorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/examen")
public class ProfesorController {
    @Autowired
    private ProfesorService profeService;

    @GetMapping("/listar")
    public ResponseEntity<List<Profesor>> listarprofe() {
        return new ResponseEntity<List<Profesor>>(profeService.findByAll(),
                HttpStatus.OK);
    }
    @PostMapping("/crear")
    public ResponseEntity<Profesor> crearprofe(
            @RequestBody Profesor p) {
        return new ResponseEntity<>(profeService.save(p),
                HttpStatus.CREATED);
    }

    @PutMapping("/actualizar/{id}")
    public ResponseEntity<Profesor> actualizarprofe(@PathVariable Long id, @RequestBody Profesor p) {
        Profesor r = profeService.findById(id);
        if (r == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } else {
            try {
                r.setNombre(p.getNombre());
                r.setApellido(p.getApellido());
                r.setCelular(p.getCelular());
                r.setCorreo(p.getCorreo());
                r.setCorreo(p.getCorreo());
                r.setListaAsignaruta(p.getListaAsignaruta());
                r.setCiclo(p.getCiclo());
                return new ResponseEntity<>(profeService.save(r), HttpStatus.OK);
            } catch (DataAccessException e) {
                return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
    }

    @DeleteMapping("/eliminar/{id}")
    public ResponseEntity<Profesor> eliminarprofe(@PathVariable Long id) {
        profeService.delete(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
